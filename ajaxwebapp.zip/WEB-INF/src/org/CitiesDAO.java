package org;
import java.sql.*;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class CitiesDAO {
	
	 /**
     * Get a connection from a specified datasource
     * @param dataSourceName name
     * @return Connection
     */
    public Connection getConnection(String dataSourceName) throws SQLException {
    	InitialContext context = null;
    	try {
    		context = new javax.naming.InitialContext();
    		DataSource aDataSource = (DataSource) context.lookup(dataSourceName);
    		return aDataSource.getConnection();
    	} 
		catch(Exception ex) {
    		ex.printStackTrace();
    		return null;
    	}
    }
    
    /**
     * constructs the xml string to be sent to the browser
     * @param prefix
     * @return
     */
    public String getCitiesByName (String prefix) {
    	Connection conn = null;
    	PreparedStatement psmt = null;
    	ResultSet rs = null;
		StringBuffer cities = new StringBuffer();
    	String sql = "select city_name from city where city_name like ?";
    	try {
    		conn = getConnection("dsDB");//substitute dsDB with your datasource name
    		psmt = conn.prepareStatement(sql);
    		psmt.setString(1,searchText+"%");
    		rs = psmt.executeQuery();
    		//construct the xml string.
    		cities.append("<cities>");
    		while(rs.next()) {
    			cities.append("<city>"+rs.getString("city_name")+"</city>");
    		}
    		cities.append("</cities>");
			rs.close();psmt.close();
    		
    	} 
		catch(SQLException se) {
    		se.printStackTrace();
    	} 
		finally {
    		try { 
				conn.close(); 
			} 
			catch(Exception e) { 
				e.printStackTrace()
			};
    	}
    	return cities.toString();
    }
}
