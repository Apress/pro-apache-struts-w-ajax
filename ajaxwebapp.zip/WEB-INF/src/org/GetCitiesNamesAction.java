package org;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.*;




public class GetCitiesNamesAction extends Action {
	
    public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception {
    	CitiesDAO citiesDAO = new CitiesDAO();
    	String searchText = request.getParameter("getCities");
    	String cities = citiesDAO.getCitiesByName(searchText);
    	response.setContentType("application/xml");
        response.getWriter().write(cities);
        return null;
    }
}
